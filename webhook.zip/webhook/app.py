from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
import mysql.connector
from mysql.connector import Error
from flask_bcrypt import Bcrypt
from flask_httpauth import HTTPBasicAuth
import traceback
import requests
from flask_wtf import FlaskForm    # flask_wtf module, which provides easy integration of WTForms with Flask.
from wtforms import StringField, SubmitField   # WTForms is a form validation and rendering library for Python web development.
from wtforms.validators import DataRequired, URL

app = Flask(__name__)
app.config['SECRET_KEY'] = 'AsdeT%$#utry'  # Needed for Flask-WTF

auth = HTTPBasicAuth()
bcrypt = Bcrypt(app)

# Database configuration
DB_CONFIG = {
    'host': '127.0.0.1',
    'port': '3306',
    'database': 'DB_name',
    'user': 'User_name',
    'password': 'Your-db-password'
}

def get_db_connection():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            return connection
    except Error as e:
        print("Error connecting to the database:", e)
        traceback.print_exc()
    return None

@auth.verify_password   # Authentication Section
def verify_password(username, password):
    if username:
        connection = get_db_connection()
        if connection:
            try:
                cursor = connection.cursor(dictionary=True)
                cursor.execute("SELECT password_hash FROM users WHERE username = %s", (username,))
                user = cursor.fetchone()
                if user and bcrypt.check_password_hash(user['password_hash'], password):
                    return username
            except Error as e:
                print("Error during authentication:", e)
                traceback.print_exc()
            finally:
                cursor.close()
                connection.close()
    return None

class SubscribeForm(FlaskForm):
    url = StringField('Subscriber URL', validators=[DataRequired(), URL()])
    submit = SubmitField('Subscribe')             # another field type from WTForms used to handle form submission buttons.

@app.route('/subscribe', methods=['GET', 'POST'])
def subscribe():
    form = SubscribeForm()
    if form.validate_on_submit():
        subscriber_url = form.url.data
        connection = get_db_connection()
        if connection:
            try:
                cursor = connection.cursor()
                cursor.execute("INSERT INTO subscribers (url) VALUES (%s)", (subscriber_url,))
                connection.commit()
                flash("Subscribed successfully", "success")
                return redirect(url_for('subscribe'))
            except Error as e:
                connection.rollback()
                if e.errno == 1062:  # Duplicate entry error code for MySQL
                    flash("URL already subscribed", "danger")
                else:
                    flash("Failed to subscribe", "danger")
                print(f"Error code: {e.errno}")
                print(f"Error message: {e.msg}")
                # print("Error subscribing:", e)
                traceback.print_exc()
            finally:
                cursor.close()
                connection.close()
    subscribers = get_subscribers()
    return render_template('subscribe.html', form=form, subscribers=subscribers)

@app.route('/unsubscribe', methods=['POST'])
def unsubscribe():
    subscriber_url = request.form.get('url')
    if subscriber_url:
        connection = get_db_connection()
        if connection:
            try:
                cursor = connection.cursor()
                cursor.execute("DELETE FROM subscribers WHERE url = %s", (subscriber_url,))
                connection.commit()
                flash("Unsubscribed successfully", "success")
            except Error as e:
                print("Error unsubscribing:", e)
                traceback.print_exc()
                flash("Failed to unsubscribe", "danger")
            finally:
                cursor.close()
                connection.close()
    return redirect(url_for('subscribe'))

def get_subscribers():
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT url FROM subscribers")
            subscribers = cursor.fetchall()
            return [subscriber['url'] for subscriber in subscribers]   #  Extracts the url value from each dictionary in the subscribers list.
        except Error as e:
            print("Error fetching subscribers:", e)
            traceback.print_exc()
        finally:
            cursor.close()
            connection.close()
    return []

def insert_data(temp, hum):
    try:
        username = auth.current_user()
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor()
            insert_query = "INSERT INTO sensor(temp, hum, username) VALUES(%s,%s,%s)"
            data = (temp, hum, username)
            cursor.execute(insert_query, data)
            connection.commit()
            print("Data inserted successfully")
            notify_subscribers(temp, hum, username)
    except Error as e:
        print("MySQL Error:", e)
        traceback.print_exc()
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

def notify_subscribers(temp, hum, username):
    data = {
        'temp': temp,
        'hum': hum,
        'username': username
    }
    headers = {'Content-Type': 'application/json'}
    
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT url FROM subscribers")
            subscribers = cursor.fetchall()
            
            for subscriber in subscribers:
                subscriber_url = subscriber['url']
                try:
                    response = requests.post(subscriber_url, json=data, headers=headers)
                    if response.status_code == 200:
                        print(f"Notification sent to {subscriber_url}")
                    else:
                        print(f"Failed to notify {subscriber_url}, status code: {response.status_code}")
                except requests.exceptions.RequestException as e:
                    print(f"Error notifying {subscriber_url}: {e}")
        except Error as e:
            print("Error fetching subscribers:", e)
            traceback.print_exc()
        finally:
            cursor.close()
            connection.close()

@app.route('/data', methods=['POST'])
@auth.login_required
def received_data():
    try:
        data = request.get_json()
        if data:
            print("Received data:", data)
            temp = data.get('temp')
            hum = data.get('hum')
            if temp is not None and hum is not None:
                insert_data(temp, hum)
                return jsonify({"message": "Data received", "data": data}), 200
            else:
                return jsonify({"error": "Invalid data format"}), 400
        else:
            return jsonify({"error": "No data received"}), 400
    except Exception as e:
        print("Error:", e)
        traceback.print_exc()
        return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    app.run(debug=True)
