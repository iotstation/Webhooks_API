from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/updates', methods=['POST'])
def receive_update():
    try:
        data = request.get_json()
        if data:
            print("Received update:", data)
            # Process the received data as needed
            return jsonify({"message": "Update received"}), 200
        else:
            return jsonify({"error": "No data received"}), 400
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=6001)
